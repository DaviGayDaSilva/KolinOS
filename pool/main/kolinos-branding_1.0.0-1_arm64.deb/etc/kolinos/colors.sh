# KolinOS brand colours (rendered from VERSION). POSIX-sh compatible.
# Usage:  . /etc/kolinos/colors.sh
# Only emits escape codes when stdout is a terminal, so redirecting to a file
# (logging, piping) never leaves stray escapes in the output.
KOLIN_COLOR_PRIMARY='99'
KOLIN_COLOR_ACCENT='44'
KOLIN_COLOR_MUTED='245'
KOLIN_COLOR_OK='76'
KOLIN_COLOR_WARN='214'
KOLIN_COLOR_ERR='203'

if [ -t 1 ]; then
    KOLIN_C_PRIMARY="$(printf '\033[38;5;%sm' "$KOLIN_COLOR_PRIMARY")"
    KOLIN_C_ACCENT="$(printf '\033[38;5;%sm'  "$KOLIN_COLOR_ACCENT")"
    KOLIN_C_MUTED="$(printf '\033[38;5;%sm'   "$KOLIN_COLOR_MUTED")"
    KOLIN_C_OK="$(printf '\033[38;5;%sm'      "$KOLIN_COLOR_OK")"
    KOLIN_C_WARN="$(printf '\033[38;5;%sm'    "$KOLIN_COLOR_WARN")"
    KOLIN_C_ERR="$(printf '\033[38;5;%sm'     "$KOLIN_COLOR_ERR")"
    KOLIN_C_BOLD="$(printf '\033[1m')"
    KOLIN_C_RESET="$(printf '\033[0m')"
else
    KOLIN_C_PRIMARY=''; KOLIN_C_ACCENT=''; KOLIN_C_MUTED=''
    KOLIN_C_OK=''; KOLIN_C_WARN=''; KOLIN_C_ERR=''
    KOLIN_C_BOLD=''; KOLIN_C_RESET=''
fi
